#!/usr/bin/env python3
"""Verify the generated e8b16/e9b1..e9b9 JB matrix against immutable evidence."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXPECTED_VERSIONS=["e8b16","e9b1","e9b2","e9b3","e9b4","e9b5","e9b6","e9b7","e9b8","e9b9"]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fail(msg): raise SystemExit(msg)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('matrix',nargs='?',default='reports/jailbreakbench-2026-10-04/E8_E9_JB_METRICS_MATRIX.json'); a=ap.parse_args()
    p=ROOT/ a.matrix; d=json.loads(p.read_text())
    if d.get('schema')!='gpt-jb-e8-e9-metrics-v1': fail('schema mismatch')
    rows=d.get('rows',[])
    if len(rows)!=40: fail(f'row count {len(rows)} != 40')
    keys={(r['line'],r['version'],r['suite']) for r in rows}
    expected={(line,v,s) for line in ('gpt-6-astra','gpt-6.1-sol') for v in EXPECTED_VERSIONS for s in ('JB-A','JB-B')}
    if keys!=expected: fail('matrix key set mismatch')
    checked=0
    for r in rows:
        if r['status'].startswith('not_'):
            if any(r.get(k) is not None for k in ('selected','target_attempted','completed_target','provider_policy_block','raw_results','summary','official_asr_on_judged')): fail(f"not-run populated: {r}")
            continue
        raw=ROOT/r['raw_results']; summary=ROOT/r['summary']
        if not raw.exists() or not summary.exists(): fail(f'missing evidence: {r}')
        if sha(raw)!=r['raw_results_sha256']: fail(f'raw hash mismatch: {raw}')
        if sha(summary)!=r['summary_sha256']: fail(f'summary hash mismatch: {summary}')
        sd=json.loads(summary.read_text())
        if r.get('version') == 'e9b9':
            if sd.get('schema') != 'jbb-line-diagnostic-summary-v2': fail(f'live summary schema: {summary}')
            if r.get('manual_v2_status') != 'completed_v2': fail(f'live v2 status: {r}')
            if r.get('official_asr_on_judged') is not None: fail(f'fabricated live official score: {r}')
            if r.get('target_attempted') != r.get('selected'): fail(f'live attempt mismatch: {r}')
            if r.get('selected') != r.get('completed_target') + r.get('provider_policy_block'): fail(f'live count mismatch: {r}')
            refusal = sd.get('manual_refusal_rate')
            disqualifier = sd.get('manual_cheating_or_protocol_rate')
            if refusal is None or abs(float(r.get('manual_refusal_rate_on_completed')) - float(refusal)) > 1e-12: fail(f'live refusal rate mismatch: {r}')
            if disqualifier is None or abs(float(r.get('manual_cheating_or_protocol_rate_on_completed')) - float(disqualifier)) > 1e-12: fail(f'live disqualifier rate mismatch: {r}')
            if int(sd.get('manual_reviewed_completed', -1)) != int(r.get('completed_target')): fail(f'live manual count mismatch: {r}')
            checked += 1
            continue
        if sd.get('schema')!='jbb-human-review-summary-v1': fail(f'summary schema: {summary}')
        if r['official_asr_on_judged'] is not None: fail(f'fabricated official score: {r}')
        if r['manual_v2_status']!='not_annotated_historical_v1': fail(f'v2 status: {r}')
        if r['manual_refusal_rate_on_completed'] is not None or r['manual_cheating_or_protocol_rate_on_completed'] is not None: fail(f'fabricated v2 rate: {r}')
        if r['target_attempted'] != r['selected']: fail(f'attempt mismatch: {r}')
        if r['selected'] != r['completed_target'] + r['provider_policy_block']: fail(f'count mismatch: {r}')
        if r['manual_v1_safe'] + r['manual_v1_unsafe'] != r['completed_target']: fail(f'manual count mismatch: {r}')
        checked += 1
    print(json.dumps({'schema':d['schema'],'rows':len(rows),'completed_rows':checked,'not_run_rows':len(rows)-checked,'status':'pass'},ensure_ascii=False))
    return 0
if __name__=='__main__': raise SystemExit(main())
