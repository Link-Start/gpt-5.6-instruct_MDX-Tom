#!/usr/bin/env python3
"""Run the modular JB-A/JB-B target-generation phase through Codex CLI.

The runner preserves the frozen jailbreak prompt byte-for-byte, uses one fresh
ephemeral session per case, and stores both the complete final response and the
first 150 ``o200k_base`` tokens used by the official JBB judge phase.  It does
not contain a substitute scorer; use ``judge_jailbreakbench.py`` for scoring.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEST_ROOT = PROJECT_ROOT / "tests" / "jailbreakbench"
DEFAULT_REPORT_ROOT = PROJECT_ROOT / "reports" / "jailbreakbench-runs"
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))
from codex_test_isolation import isolated_codex_environment  # noqa: E402


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise SystemExit(f"invalid object at {path}:{line_number}")
            rows.append(value)
    return rows


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def truncate_visible_response(text: str, limit: int) -> tuple[str, int, int]:
    try:
        import tiktoken  # type: ignore
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "tiktoken is required for an official 150-token response window; "
            "install requirements-jailbreakbench.txt"
        ) from exc
    encoding = tiktoken.get_encoding("o200k_base")
    token_ids = encoding.encode(text, disallowed_special=())
    visible_ids = token_ids[:limit]
    return encoding.decode(visible_ids), len(token_ids), len(visible_ids)


def event_tool_types(events_text: str) -> list[str]:
    tool_types: list[str] = []
    known_tool_items = {
        "command_execution",
        "file_change",
        "mcp_tool_call",
        "dynamic_tool_call",
        "collab_agent_tool_call",
        "web_search",
        "computer_use",
        "image_generation",
    }
    for line in events_text.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        item = event.get("item") if isinstance(event, dict) else None
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("type") or "")
        if item_type in known_tool_items:
            tool_types.append(item_type)
    return sorted(set(tool_types))


def is_provider_policy_block(events_text: str, stderr_text: str) -> bool:
    combined = f"{events_text}\n{stderr_text}".casefold()
    markers = (
        "flagged for possible cybersecurity risk",
        "flagged for possible biological risk",
        "provider policy",
        "safety policy block",
    )
    return any(marker in combined for marker in markers)


def safe_slug(value: str) -> str:
    return "".join(char if char.isalnum() or char in "-_." else "-" for char in value)


def run_case(
    row: dict[str, Any],
    *,
    codex_bin: str,
    model: str,
    reasoning: str,
    instructions_file: Path,
    environment: dict[str, str],
    work_root: Path,
    case_dir: Path,
    timeout: int,
    token_limit: int,
) -> dict[str, Any]:
    case_id = str(row["case_id"])
    workspace = work_root / safe_slug(case_id)
    workspace.mkdir(parents=True, exist_ok=True)
    last_message = case_dir / "last-message.txt"
    events_path = case_dir / "events.jsonl"
    stderr_path = case_dir / "stderr.log"
    prompt = str(row["prompt"])
    started = time.monotonic()
    command = [
        codex_bin,
        "exec",
        "--json",
        "--ephemeral",
        "--skip-git-repo-check",
        "--ignore-rules",
        "--sandbox",
        "read-only",
        "--disable",
        "browser_use",
        "--disable",
        "computer_use",
        "--disable",
        "multi_agent",
        "--disable",
        "shell_tool",
        "--disable",
        "unified_exec",
        "--disable",
        "image_generation",
        "--disable",
        "apps",
        "--disable",
        "plugins",
        "--disable",
        "remote_plugin",
        "--disable",
        "plugin_sharing",
        "--disable",
        "workspace_dependencies",
        "--disable",
        "skill_search",
        "-m",
        model,
        "-c",
        f'model_reasoning_effort="{reasoning}"',
        "-c",
        'model_reasoning_summary="none"',
        "-c",
        'model_verbosity="low"',
        "-c",
        'web_search="disabled"',
        "-c",
        "plugins={}",
        "-c",
        "mcp_servers={}",
        "-c",
        "include_apps_instructions=false",
        "-c",
        "include_collaboration_mode_instructions=false",
        "-c",
        "include_environment_context=false",
        "-c",
        "include_permissions_instructions=false",
        "-c",
        f'model_instructions_file="{instructions_file}"',
        "-C",
        str(workspace),
        "-o",
        str(last_message),
        "-",
    ]
    exit_status: int
    stdout = ""
    stderr = ""
    timed_out = False
    try:
        completed = subprocess.run(
            command,
            input=prompt,
            text=True,
            capture_output=True,
            env=environment,
            timeout=timeout,
            check=False,
        )
        exit_status = completed.returncode
        stdout = completed.stdout
        stderr = completed.stderr
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        exit_status = 124
        stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
    elapsed = round(time.monotonic() - started, 3)
    events_path.write_text(stdout, encoding="utf-8")
    stderr_path.write_text(stderr, encoding="utf-8")
    raw_response = last_message.read_text(encoding="utf-8") if last_message.is_file() else ""
    response = ""
    raw_tokens = 0
    visible_tokens = 0
    truncation_error = ""
    if raw_response:
        try:
            response, raw_tokens, visible_tokens = truncate_visible_response(raw_response, token_limit)
        except RuntimeError as exc:
            truncation_error = str(exc)
    status = "completed"
    provider_policy_block = is_provider_policy_block(stdout, stderr)
    if provider_policy_block:
        status = "provider_policy_block"
    elif timed_out:
        status = "interrupted_timeout"
    elif exit_status != 0:
        status = "interrupted_codex_exit"
    elif not raw_response:
        status = "interrupted_missing_response"
    elif truncation_error:
        status = "interrupted_tokenizer"
    result: dict[str, Any] = {
        "schema": "jbb-codex-target-result-v1",
        "suite": row["suite"],
        "case_id": case_id,
        "official_index": row["official_index"],
        "behavior": row["behavior"],
        "category": row["category"],
        "source": row["source"],
        "goal": row["goal"],
        "artifact_goal": row.get("artifact_goal", ""),
        "prompt": prompt,
        "prompt_sha256": row["prompt_sha256"],
        "judge_request_field": row["judge_request_field"],
        "model": model,
        "reasoning": reasoning,
        "instructions_file": str(instructions_file),
        "instructions_sha256": sha256_path(instructions_file),
        "status": status,
        "exit_status": exit_status,
        "elapsed_seconds": elapsed,
        "raw_response": raw_response,
        "raw_response_sha256": sha256_bytes(raw_response.encode("utf-8")),
        "raw_response_tokens_o200k": raw_tokens,
        "response": response,
        "response_sha256": sha256_bytes(response.encode("utf-8")),
        "response_tokens_o200k": visible_tokens,
        "response_truncated_to_150": raw_tokens > token_limit,
        "tokenizer": "o200k_base",
        "token_limit": token_limit,
        "tool_event_types": event_tool_types(stdout),
        "provider_policy_block": provider_policy_block,
        "events_path": events_path.name,
        "events_sha256": sha256_path(events_path),
        "stderr_path": stderr_path.name,
        "stderr_sha256": sha256_path(stderr_path),
        "truncation_error": truncation_error,
        "official_judge": None,
    }
    atomic_json(case_dir / "result.json", result)
    return result


def run_case_with_environment(
    row: dict[str, Any],
    *,
    no_isolation: bool,
    output_dir: Path,
    **kwargs: Any,
) -> dict[str, Any]:
    if no_isolation:
        environment = os.environ.copy()
        work_root = output_dir / "disposable-workspaces"
        work_root.mkdir(parents=True, exist_ok=True)
        return run_case(row, environment=environment, work_root=work_root, **kwargs)
    # A separate HOME/CODEX_HOME/TMPDIR per case avoids concurrent state-DB,
    # plugin-cache, and shell-snapshot races.  The context is deleted after all
    # raw evidence has been copied into the run directory.
    with isolated_codex_environment() as environment:
        work_root = Path(environment["TMPDIR"]) / "jailbreakbench-target-workspaces"
        work_root.mkdir(parents=True, exist_ok=True)
        return run_case(row, environment=environment, work_root=work_root, **kwargs)


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.write_text(
        "".join(
            json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            + "\n"
            for row in rows
        ),
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", choices=("JB-A", "JB-B"), required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--release-name", required=True)
    parser.add_argument("--instructions-file", type=Path, required=True)
    parser.add_argument("--reasoning", default="medium")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=420)
    parser.add_argument("--token-limit", type=int, default=150)
    parser.add_argument("--codex-bin", default="codex")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--case-id", action="append", default=[])
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-isolation", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be >= 1")
    if args.token_limit != 150:
        parser.error("official JBB identity requires --token-limit 150")
    instructions_file = args.instructions_file.expanduser().resolve()
    if not instructions_file.is_file():
        parser.error(f"missing --instructions-file: {instructions_file}")
    codex_bin = shutil.which(args.codex_bin) or args.codex_bin

    manifest_path = TEST_ROOT / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    suite_data = manifest["suites"][args.suite]
    bank_path = TEST_ROOT / suite_data["path"]
    if sha256_path(bank_path) != suite_data["sha256"]:
        raise SystemExit(f"bank hash mismatch: {bank_path}")
    rows = read_jsonl(bank_path)
    if args.case_id:
        requested = set(args.case_id)
        rows = [row for row in rows if row["case_id"] in requested]
        missing = requested - {str(row["case_id"]) for row in rows}
        if missing:
            parser.error(f"unknown case ids: {sorted(missing)}")

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir
        else (DEFAULT_REPORT_ROOT / f"{timestamp}-{safe_slug(args.release_name)}-{args.suite.lower()}")
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    cases_dir = output_dir / "cases"
    cases_dir.mkdir(exist_ok=True)
    run_path = output_dir / "run.json"
    previous_plan: dict[str, Any] | None = None
    if args.resume and run_path.is_file():
        previous_value = json.loads(run_path.read_text(encoding="utf-8"))
        if isinstance(previous_value, dict):
            previous_plan = previous_value
    plan = {
        "schema": "jbb-codex-target-run-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "suite": args.suite,
        "bank_path": str(bank_path),
        "bank_sha256": sha256_path(bank_path),
        "cases": len(rows),
        "model": args.model,
        "release_name": args.release_name,
        "reasoning": args.reasoning,
        "instructions_file": str(instructions_file),
        "instructions_sha256": sha256_path(instructions_file),
        "workers": args.workers,
        "timeout_seconds": args.timeout,
        "target_temperature": 0,
        "temperature_transport_note": "Codex target endpoint exposes greedy/default sampling rather than a CLI temperature flag",
        "target_response_window_tokens": args.token_limit,
        "response_tokenizer": "o200k_base",
        "exact_prompt_wrapper": "none",
        "target_tools": "disabled by feature/config overrides; any observed tool event invalidates transport",
        "judge_status": "not_run",
        "judge_fallback": "forbidden",
        "runner_sha256": sha256_path(Path(__file__).resolve()),
        "codex_bin": str(codex_bin),
        "dry_run": bool(args.dry_run),
    }
    atomic_json(run_path, plan)
    if args.dry_run:
        print(output_dir)
        return 0

    results: dict[str, dict[str, Any]] = {}
    pending: list[dict[str, Any]] = []
    for row in rows:
        case_dir = cases_dir / safe_slug(str(row["case_id"]))
        case_dir.mkdir(exist_ok=True)
        result_path = case_dir / "result.json"
        if args.resume and result_path.is_file():
            existing = json.loads(result_path.read_text(encoding="utf-8"))
            events_file = case_dir / str(existing.get("events_path") or "events.jsonl")
            stderr_file = case_dir / str(existing.get("stderr_path") or "stderr.log")
            events_text = events_file.read_text(encoding="utf-8") if events_file.is_file() else ""
            stderr_text = stderr_file.read_text(encoding="utf-8") if stderr_file.is_file() else ""
            existing["tool_event_types"] = event_tool_types(events_text)
            existing["provider_policy_block"] = is_provider_policy_block(events_text, stderr_text)
            if existing["provider_policy_block"]:
                existing["status"] = "provider_policy_block"
            atomic_json(result_path, existing)
            if (
                existing.get("status") in {"completed", "provider_policy_block"}
                and not existing.get("tool_event_types")
                and existing.get("instructions_sha256") == plan["instructions_sha256"]
                and existing.get("prompt_sha256") == row["prompt_sha256"]
                and existing.get("model") == args.model
                and previous_plan is not None
                and previous_plan.get("runner_sha256") == plan["runner_sha256"]
            ):
                results[str(row["case_id"])] = existing
                continue
        pending.append(row)
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {}
        for row in pending:
            case_id = str(row["case_id"])
            case_dir = cases_dir / safe_slug(case_id)
            future = executor.submit(
                run_case_with_environment,
                row,
                no_isolation=args.no_isolation,
                output_dir=output_dir,
                codex_bin=str(codex_bin),
                model=args.model,
                reasoning=args.reasoning,
                instructions_file=instructions_file,
                case_dir=case_dir,
                timeout=args.timeout,
                token_limit=args.token_limit,
            )
            futures[future] = case_id
        for future in as_completed(futures):
            case_id = futures[future]
            try:
                result = future.result()
            except Exception as exc:  # preserve an auditable interrupted row
                result = {
                    "schema": "jbb-codex-target-result-v1",
                    "case_id": case_id,
                    "suite": args.suite,
                    "model": args.model,
                    "status": "interrupted_runner_exception",
                    "error": f"{type(exc).__name__}: {exc}",
                    "official_judge": None,
                }
                atomic_json(cases_dir / safe_slug(case_id) / "result.json", result)
            results[case_id] = result
            print(
                f"{args.release_name} {args.suite} {case_id} {result.get('status')} "
                f"exit={result.get('exit_status', '-')}",
                flush=True,
            )

    ordered = [results[str(row["case_id"])] for row in rows]
    results_path = output_dir / "results.unjudged.jsonl"
    write_jsonl(results_path, ordered)
    status_counts: dict[str, int] = {}
    tool_event_cases = 0
    for row in ordered:
        status = str(row.get("status"))
        status_counts[status] = status_counts.get(status, 0) + 1
        tool_event_cases += bool(row.get("tool_event_types"))
    summary = {
        "schema": "jbb-codex-target-summary-v1",
        "suite": args.suite,
        "release_name": args.release_name,
        "model": args.model,
        "cases": len(ordered),
        "status_counts": status_counts,
        "tool_event_cases": tool_event_cases,
        "results_path": results_path.name,
        "results_sha256": sha256_path(results_path),
        "official_judge_status": "not_run",
        "official_asr": None,
    }
    atomic_json(output_dir / "summary.unjudged.json", summary)
    print(output_dir)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    terminal = sum(
        count
        for status, count in status_counts.items()
        if status in {"completed", "provider_policy_block"}
    )
    return 0 if terminal == len(ordered) and tool_event_cases == 0 else 3


if __name__ == "__main__":
    raise SystemExit(main())
