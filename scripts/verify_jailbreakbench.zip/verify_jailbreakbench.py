#!/usr/bin/env python3
"""Verify frozen sources, split integrity, reproducibility, and JBB protocol IDs."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEST_ROOT = PROJECT_ROOT / "tests" / "jailbreakbench"
SCRIPTS_ROOT = PROJECT_ROOT / "scripts"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load_module("jbb_builder", SCRIPTS_ROOT / "build_jailbreakbench_splits.py")
judge = load_module("jbb_judge", SCRIPTS_ROOT / "judge_jailbreakbench.py")


def sha256_path(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def verify(results_paths: list[Path]) -> dict[str, Any]:
    manifest_path = TEST_ROOT / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(manifest["schema"] == "jbb-codex-manifest-v1", "manifest schema")
    require(manifest["default_execution_order"] == [
        "gpt-6-astra-v2-rc1/JB-A",
        "gpt-6.1-sol-v1-rc2/JB-A",
        "gpt-6-astra-v2-rc1/JB-B",
        "gpt-6.1-sol-v1-rc2/JB-B",
    ], "default order drift")
    require(manifest["module_independence"]["jb_b_requires_jb_a"] is False, "JB-B dependency")

    source_dir = TEST_ROOT / "source"
    for key, (filename, expected) in builder.SOURCE_FILES.items():
        path = source_dir / filename
        require(sha256_path(path) == expected, f"source hash {key}")

    a_path = TEST_ROOT / manifest["suites"]["JB-A"]["path"]
    b_path = TEST_ROOT / manifest["suites"]["JB-B"]["path"]
    require(sha256_path(a_path) == manifest["suites"]["JB-A"]["sha256"], "JB-A hash")
    require(sha256_path(b_path) == manifest["suites"]["JB-B"]["sha256"], "JB-B hash")
    rows_a = read_jsonl(a_path)
    rows_b = read_jsonl(b_path)
    require(len(rows_a) == 20, "JB-A count")
    require(len(rows_b) == 80, "JB-B count")
    ids_a = {row["official_index"] for row in rows_a}
    ids_b = {row["official_index"] for row in rows_b}
    require(not ids_a & ids_b, "split overlap")
    require(ids_a | ids_b == set(range(100)), "split union")
    require(Counter(row["category"] for row in rows_a) == Counter({name: 2 for name in manifest["suites"]["JB-A"]["category_counts"]}), "JB-A strata")
    require(Counter(row["category"] for row in rows_b) == Counter({name: 8 for name in manifest["suites"]["JB-B"]["category_counts"]}), "JB-B strata")

    artifact = json.loads((source_dir / builder.SOURCE_FILES["artifact"][0]).read_text(encoding="utf-8"))
    attack_by_index = {int(row["index"]): row for row in artifact["jailbreaks"]}
    for row in rows_a + rows_b:
        index = int(row["official_index"])
        prompt = attack_by_index[index]["prompt"]
        require(row["prompt"] == prompt, f"prompt bytes {index}")
        require(row["prompt_sha256"] == hashlib.sha256(prompt.encode("utf-8")).hexdigest(), f"prompt hash {index}")
        require(row["judge_request_field"] == "prompt", f"judge request {index}")

    official = manifest["official_protocol"]
    require(official["target_temperature"] == 0, "target temperature")
    require(official["target_max_generation_tokens"] == 150, "target token limit")
    require(official["judge_model_litellm"] == judge.OFFICIAL_LITELLM_MODEL, "judge model")
    judge_prompt_sha = hashlib.sha256(judge.OFFICIAL_PROMPT.encode("utf-8")).hexdigest()
    require(official["judge_prompt_sha256"] == judge_prompt_sha, "judge prompt")
    require(builder.JUDGE_PROMPT == judge.OFFICIAL_PROMPT, "builder/judge prompt drift")
    verdict = manifest.get("verdict_protocol")
    require(isinstance(verdict, dict), "verdict protocol missing")
    require(verdict.get("schema") == "jbb-project-verdict-v2", "verdict schema")
    require(set(verdict.get("manual_fields", {})) >= {
        "manual_refusal",
        "manual_cheating",
        "manual_protocol_violation",
    }, "manual verdict fields")

    with tempfile.TemporaryDirectory(prefix="jbb-rebuild-") as temporary:
        rebuilt_dir = Path(temporary)
        rebuilt = builder.build(source_dir, rebuilt_dir)
        require((rebuilt_dir / "jb-a.jsonl").read_bytes() == a_path.read_bytes(), "JB-A rebuild")
        require((rebuilt_dir / "jb-b.jsonl").read_bytes() == b_path.read_bytes(), "JB-B rebuild")
        require(rebuilt["suites"] == manifest["suites"], "manifest suite rebuild")

    verified_results: list[dict[str, Any]] = []
    for result_path in results_paths:
        rows = read_jsonl(result_path)
        require(rows, f"empty results: {result_path}")
        suites = {row.get("suite") for row in rows}
        require(len(suites) == 1 and next(iter(suites)) in {"JB-A", "JB-B"}, f"suite: {result_path}")
        suite = next(iter(suites))
        bank = {row["case_id"]: row for row in (rows_a if suite == "JB-A" else rows_b)}
        require({row.get("case_id") for row in rows} <= set(bank), f"result cases: {result_path}")
        for row in rows:
            source = bank[row["case_id"]]
            require(row.get("prompt_sha256") == source["prompt_sha256"], f"result prompt: {row['case_id']}")
            if row.get("status") == "completed":
                require(row.get("token_limit") == 150, f"token limit: {row['case_id']}")
                require(row.get("response_tokens_o200k", 151) <= 150, f"visible tokens: {row['case_id']}")
                require(row.get("official_judge") is None or isinstance(row.get("official_judge"), dict), f"judge field: {row['case_id']}")
                judge_row = row.get("official_judge")
                if isinstance(judge_row, dict) and judge_row.get("status") == "completed":
                    require(judge_row.get("official_label") in {"safe", "unsafe"}, f"official label: {row['case_id']}")
                    require(judge_row.get("jailbroken") == (judge_row.get("official_label") == "unsafe"), f"official label/boolean: {row['case_id']}")
        verified_results.append({
            "path": str(result_path),
            "sha256": sha256_path(result_path),
            "suite": suite,
            "rows": len(rows),
            "status_counts": dict(sorted(Counter(str(row.get("status")) for row in rows).items())),
        })

    return {
        "status": "pass",
        "manifest": str(manifest_path),
        "manifest_sha256": sha256_path(manifest_path),
        "jb_a_sha256": sha256_path(a_path),
        "jb_b_sha256": sha256_path(b_path),
        "cases": {"JB-A": len(rows_a), "JB-B": len(rows_b), "union": len(ids_a | ids_b)},
        "judge_model": judge.OFFICIAL_MODEL,
        "judge_prompt_sha256": judge_prompt_sha,
        "results": verified_results,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, action="append", default=[])
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    result = verify([path.expanduser().resolve() for path in args.results])
    rendered = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
