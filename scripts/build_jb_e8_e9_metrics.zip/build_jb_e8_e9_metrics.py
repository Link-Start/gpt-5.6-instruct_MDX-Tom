#!/usr/bin/env python3
"""Build an auditable JB-A/JB-B matrix for e8b16, e9b1..e9b9.

The builder reads immutable raw results plus the live e9b9 manual-v2 line
summaries. It never invents an official judge label. Historical rows retain
their v1 diagnostic layer; missing suites remain explicit ``not_run_gate`` rows.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]

# (line, version, release directory, evidence date root, available suites,
#  historical note)
SPECS = [
    ("gpt-6-astra", "e8b16", "gpt-6-astra-v2-rc1", "reports/jailbreakbench-2026-10-03", ("JB-A", "JB-B"), "published e8b16 evidence"),
    ("gpt-6.1-sol", "e8b16", "gpt-6.1-sol-v1-rc2", "reports/jailbreakbench-2026-10-03", ("JB-A", "JB-B"), "published e8b16 evidence"),
]
for beta in range(1, 9):
    root = "reports/jailbreakbench-2026-10-03" if beta <= 2 else "reports/jailbreakbench-2026-10-04"
    for line, release in (("gpt-6-astra", f"gpt-6-astra-v1-e9b{beta}"), ("gpt-6.1-sol", f"gpt-6.1-sol-e9b{beta}")):
        if line == "gpt-6-astra":
            suites = {1: ("JB-A", "JB-B"), 2: ("JB-A",), 3: ("JB-A", "JB-B")}.get(beta, ("JB-A",))
        else:
            suites = {1: ("JB-A",), 2: ("JB-A",), 3: ("JB-A", "JB-B"), 4: ("JB-A", "JB-B"), 6: ("JB-A", "JB-B")}.get(beta, ("JB-A",))
        note = "historical completed JB-B before the e9b3 gate wording" if line == "gpt-6-astra" and beta == 1 else "raw evidence reused"
        SPECS.append((line, f"e9b{beta}", release, root, suites, note))
# e9b9 is live evidence: JB-A was collected diagnostically after the A gate and
# carries completed manual-v2 fields; JB-B remains explicitly not_run_gate.
SPECS.extend([
    ("gpt-6-astra", "e9b9", "gpt-6-astra-v1-e9b9", "reports/jailbreakbench-2026-10-04", ("JB-A",), "A-gated line; JB-A diagnostic completed with official labels null"),
    ("gpt-6.1-sol", "e9b9", "gpt-6.1-sol-e9b9", "reports/jailbreakbench-2026-10-04", ("JB-A",), "A-gated line; JB-A diagnostic completed with official labels null"),
])

LIVE_E9B9_SUMMARIES = {
    "gpt-6-astra": ROOT / "reports/gpt6-astra-v1-epoch9-2026-10-04/e9b9/JB_A_MANUAL_SUMMARY.json",
    "gpt-6.1-sol": ROOT / "reports/gpt6.1-sol-epoch9-2026-10-04/e9b9/JB_A_MANUAL_SUMMARY.json",
}

SUMMARY_NAMES = ("summary.manual-review.json", "manual-review-summary.json")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path}: expected object")
    return value


def find_summary(suite_dir: Path) -> Path | None:
    for name in SUMMARY_NAMES:
        p = suite_dir / name
        if p.exists():
            return p
    return None


def raw_counts(raw: Path) -> dict[str, int]:
    counts: dict[str, int] = {}
    for line in raw.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        status = str(row.get("status", "unknown"))
        counts[status] = counts.get(status, 0) + 1
    return counts


def row_for(line: str, version: str, release: str, root_rel: str, suite: str, available: bool, note: str) -> dict[str, Any]:
    suite_dir = ROOT / root_rel / release / suite
    if version == "e9b9" and suite == "JB-A":
        live_summary = LIVE_E9B9_SUMMARIES[line]
        if not live_summary.exists():
            raise FileNotFoundError(f"missing live e9b9 summary: {live_summary}")
        d = load_json(live_summary)
        raw_path = ROOT / str(d["results_unjudged"] if "results_unjudged" in d else d["raw_results"])
        if not raw_path.exists():
            raise FileNotFoundError(f"missing live e9b9 raw results: {raw_path}")
        actual_raw_sha = sha256(raw_path)
        if d.get("results_unjudged_sha256") and d["results_unjudged_sha256"] != actual_raw_sha:
            raise ValueError(f"{live_summary}: raw hash mismatch")
        return {
            "line": line,
            "version": version,
            "release": release,
            "suite": suite,
            "status": "completed",
            "selected": int(d["selected"]),
            "target_attempted": int(d["selected"]),
            "completed_target": int(d["completed_target"]),
            "provider_policy_block": int(d["provider_policy_block"]),
            "manual_v1_safe": None,
            "manual_v1_unsafe": None,
            "manual_v1_unsafe_rate_on_completed": None,
            "selected_set_manual_v1_lower_bound": None,
            "selected_set_manual_v1_upper_bound": None,
            "official_judge_status": d.get("official_judge_status", "unknown"),
            "official_asr_on_judged": d.get("official_asr"),
            "manual_v2_status": "completed_v2",
            "manual_refusal_rate_on_completed": d.get("manual_refusal_rate"),
            "manual_cheating_or_protocol_rate_on_completed": d.get("manual_cheating_or_protocol_rate"),
            "manual_protocol_violation_rate_on_completed": d.get("manual_protocol_violation", 0) / int(d["completed_target"]) if d.get("completed_target") else None,
            "manual_unsafe_diagnostic": d.get("manual_unsafe_diagnostic"),
            "tool_event_cases": d.get("tool_event_cases_final", 0),
            "manual_v1_unsafe_case_ids": None,
            "provider_policy_case_ids": None,
            "official_judge_preflight": str((suite_dir / "official-judge" / "judge-run.json").relative_to(ROOT)) if (suite_dir / "official-judge" / "judge-run.json").exists() else None,
            "raw_status_counts": raw_counts(raw_path),
            "raw_results": str(raw_path.relative_to(ROOT)),
            "raw_results_sha256": actual_raw_sha,
            "summary": str(live_summary.relative_to(ROOT)),
            "summary_sha256": sha256(live_summary),
            "note": note,
        }
    if not available:
        if version == "e9b9":
            status = "not_run_gate"
            reason = note
        else:
            status = "not_run_gate"
            reason = "A non-fiction gate failed; JB-B was not run for this revision."
        return {
            "line": line,
            "version": version,
            "release": release,
            "suite": suite,
            "status": status,
            "selected": None,
            "target_attempted": None,
            "completed_target": None,
            "provider_policy_block": None,
            "manual_v1_safe": None,
            "manual_v1_unsafe": None,
            "manual_v1_unsafe_rate_on_completed": None,
            "selected_set_manual_v1_lower_bound": None,
            "selected_set_manual_v1_upper_bound": None,
            "official_judge_status": "not_run_gate",
            "official_asr_on_judged": None,
            "manual_v2_status": "not_annotated_historical_v1",
            "manual_refusal_rate_on_completed": None,
            "manual_cheating_or_protocol_rate_on_completed": None,
            "manual_v1_unsafe_case_ids": None,
            "provider_policy_case_ids": None,
            "official_judge_preflight": None,
            "raw_results": None,
            "summary": None,
            "note": reason,
        }
    summary_path = find_summary(suite_dir)
    raw_path = suite_dir / "results.unjudged.jsonl"
    if summary_path is None or not raw_path.exists():
        raise FileNotFoundError(f"missing canonical evidence for {line} {version} {suite}: {suite_dir}")
    d = load_json(summary_path)
    counts = raw_counts(raw_path)
    selected = int(d["selected"])
    completed = int(d["completed_target"])
    blocks = int(d["provider_policy_block"])
    safe = int(d["human_safe"])
    unsafe = int(d["human_unsafe"])
    if selected != len([x for x in raw_path.read_text(encoding="utf-8").splitlines() if x.strip()]):
        raise ValueError(f"{raw_path}: selected/raw line mismatch")
    if completed + blocks != selected or safe + unsafe != completed:
        raise ValueError(f"{summary_path}: inconsistent counts")
    actual_raw_sha = sha256(raw_path)
    if d.get("input_results_sha256") and d["input_results_sha256"] != actual_raw_sha:
        raise ValueError(f"{summary_path}: raw hash mismatch")
    expected_rate = unsafe / completed if completed else None
    if d.get("human_unsafe_rate_on_completed") is not None and abs(float(d["human_unsafe_rate_on_completed"]) - expected_rate) > 1e-12:
        raise ValueError(f"{summary_path}: unsafe rate mismatch")
    return {
        "line": line,
        "version": version,
        "release": release,
        "suite": suite,
        "status": "completed_historical" if version == "e8b16" or note.startswith("historical completed") else "completed",
        "selected": selected,
        "target_attempted": selected,
        "completed_target": completed,
        "provider_policy_block": blocks,
        "manual_v1_safe": safe,
        "manual_v1_unsafe": unsafe,
        "manual_v1_unsafe_rate_on_completed": expected_rate,
        "selected_set_manual_v1_lower_bound": unsafe / selected if selected else None,
        "selected_set_manual_v1_upper_bound": (unsafe + blocks) / selected if selected else None,
        "official_judge_status": d.get("official_judge_status", "unknown"),
        "official_asr_on_judged": d.get("official_jbb_score"),
        "manual_v2_status": "not_annotated_historical_v1",
        "manual_refusal_rate_on_completed": None,
        "manual_cheating_or_protocol_rate_on_completed": None,
        "tool_event_cases": d.get("tool_event_cases", 0),
        "manual_v1_unsafe_case_ids": d.get("human_unsafe_case_ids"),
        "provider_policy_case_ids": d.get("provider_policy_case_ids"),
        "official_judge_preflight": (
            str((suite_dir / "official-judge" / "judge-run.json").relative_to(ROOT))
            if (suite_dir / "official-judge" / "judge-run.json").exists() else None
        ),
        "raw_status_counts": counts,
        "raw_results": str(raw_path.relative_to(ROOT)),
        "raw_results_sha256": actual_raw_sha,
        "summary": str(summary_path.relative_to(ROOT)),
        "summary_sha256": sha256(summary_path),
        "note": note,
    }


def build() -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for line, version, release, root, available, note in SPECS:
        for suite in ("JB-A", "JB-B"):
            rows.append(row_for(line, version, release, root, suite, suite in available, note))
    return {
        "schema": "gpt-jb-e8-e9-metrics-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": {
            "versions": ["e8b16", "e9b1", "e9b2", "e9b3", "e9b4", "e9b5", "e9b6", "e9b7", "e9b8", "e9b9"],
            "lines": ["gpt-6-astra", "gpt-6.1-sol"],
            "suites": ["JB-A", "JB-B"],
        },
        "verdict_layers": {
            "official": "Exact JailbreakBench Llama3JailbreakJudge; all existing rows are unjudged because TOGETHER_API_KEY is absent.",
            "historical_manual": "Existing jbb-human-review-v1 safe/unsafe diagnostic counts, not an official score.",
            "manual_v2": "Historical rows remain unannotated; live e9b9 rows carry completed-v2 refusal, cheating, and protocol fields from their line summaries.",
        },
        "rows": rows,
    }


def pct(v: Any) -> str:
    return "—" if v is None else f"{float(v)*100:.2f}%"


def md(matrix: dict[str, Any]) -> str:
    lines = [
        "# e8b16 / e9 JB-A、JB-B 指标补齐矩阵",
        "",
        f"生成时间（UTC）：{matrix['created_at_utc']}",
        "",
        "## 口径",
        "",
        "- 本表只复用现有 `results.unjudged.jsonl`、`summary.unjudged.json` 与 `jbb-human-review-v1` 汇总；每行保留原始结果和 SHA256。",
        "- `official_*` 是 JailbreakBench 官方 Llama3JailbreakJudge 层。当前没有 `TOGETHER_API_KEY`，所以所有官方 ASR 保持 `null`，没有以人工 safe/unsafe 冒充官方标签。",
        "- `manual_v1_*` 是历史逐例人工 harmful-content 诊断；历史行的 `manual_v2` 仍为未标注，只有 e9b9 live 行显示已完成的拒答/作弊/协议率。",
        "- provider block 不进 completed 分母；`not_run_gate`、`not_run_interrupted` 和 `not_started_paired_order` 表示对应 suite 没有可计分的运行，不是零分。e9b1 Astra 的 JB-B 原始证据保留为 `completed_historical`，不改写历史身份；e9b9 JB-A 行使用现场 manual-v2 汇总，JB-B 行保持 `not_run_gate`。",
        "",
        "## 明细",
        "",
        "| 线 | 版本 | Suite | 状态 | 选中 | 尝试 | 完成 | Provider block | v1 safe | v1 unsafe | v1 unsafe/完成 | 选集下界–上界 | 官方 ASR | v2 拒答率 | v2 作弊/协议率 |",
        "|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in matrix["rows"]:
        if r["status"].startswith("not_") or r["status"].startswith("not_run") or r["status"].startswith("not_started") :
            vals = ["—"] * 12
            vals[0] = r["status"]
            lines.append(f"| {r['line']} | {r['version']} | {r['suite']} | " + " | ".join(vals) + " |")
        else:
            bounds = f"{pct(r['selected_set_manual_v1_lower_bound'])}–{pct(r['selected_set_manual_v1_upper_bound'])}"
            lines.append("| " + " | ".join([
                r["line"], r["version"], r["suite"], r["status"], str(r["selected"]), str(r["target_attempted"]), str(r["completed_target"]),
                str(r["provider_policy_block"]), "—" if r["manual_v1_safe"] is None else str(r["manual_v1_safe"]), "—" if r["manual_v1_unsafe"] is None else str(r["manual_v1_unsafe"]),
                pct(r["manual_v1_unsafe_rate_on_completed"]), bounds,
                "null" if r["official_asr_on_judged"] is None else pct(r["official_asr_on_judged"]),
                pct(r["manual_refusal_rate_on_completed"]),
                pct(r["manual_cheating_or_protocol_rate_on_completed"]),
            ]) + " |")
    lines += [
        "",
        "## 读取方式",
        "",
        "- 机器可读矩阵：`E8_E9_JB_METRICS_MATRIX.json`。",
        "- `raw_results`、`summary` 和 `official_judge_preflight` 字段是相对于项目根目录的证据路径；`*_sha256` 用于复核没有替换原始输出。",
        "- 25 个历史 completed suite 与 2 个 e9b9 live JB-A 行已生成 exact judge 的 dry-run/preflight 输入；由于当前没有 `TOGETHER_API_KEY`，官方标签保持 `null`。获得凭据后，对每个 completed 行直接运行 `scripts/judge_jailbreakbench.py`；历史行若补做 manual-v2，应另存标注并保留本表的 v1 身份。",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "reports/jailbreakbench-2026-10-04")
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    matrix = build()
    (out / "E8_E9_JB_METRICS_MATRIX.json").write_text(json.dumps(matrix, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out / "E8_E9_JB_METRICS_REPORT.md").write_text(md(matrix), encoding="utf-8")
    print(json.dumps({"rows": len(matrix["rows"]), "output_dir": str(out), "schema": matrix["schema"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
